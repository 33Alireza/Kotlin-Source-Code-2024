// This is an end-of-line comment

/* This is a block comment
on multiple lines. */

/* The comment starts here
/* contains a nested comment */
and ends here. */