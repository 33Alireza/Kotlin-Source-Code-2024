fun main(){

    val number:Int = readLine()!!.toInt()

    println("The number is $number")

}