fun main() {

    val score = Score()

    //score.plus(5)
    score + 5

    //score.div(2)
    score / 2

    //score.minus(4)
    score - 4

    //score.times(6)
    score * 6

}