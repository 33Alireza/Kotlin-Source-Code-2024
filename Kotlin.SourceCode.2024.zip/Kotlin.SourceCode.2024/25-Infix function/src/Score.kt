class Score {

    var myScore = 5

    infix fun showScore(yourScore: Int) {

        myScore += yourScore

        println(myScore)

    }
}