import java.net.ProtocolFamily

fun main() {

    val score = Score()
    score.showScore(7)
    score showScore 7

    18 average 2

    "Kotlin" showName "JetBrains"
}

infix fun Int.average(number: Int) {
    val z = (this + number) / 2
    println(z)
}

infix fun String.showName(company: String){
    println("$this -> $company")
}