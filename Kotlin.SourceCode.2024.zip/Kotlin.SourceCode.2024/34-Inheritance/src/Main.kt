fun main() {

    val dog = Dog("Husky",10)
    dog.showColor()

    val cat = Cat("Persian",5,"nully")
    cat.showColor()

}