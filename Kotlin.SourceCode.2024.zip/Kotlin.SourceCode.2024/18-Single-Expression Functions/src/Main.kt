fun sum(x: Int, y: Int) = x + y

fun main() {

    println(sum(1, 2))

}