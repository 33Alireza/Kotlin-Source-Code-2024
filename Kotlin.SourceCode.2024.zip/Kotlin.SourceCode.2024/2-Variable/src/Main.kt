fun main() {

    var boolean: Boolean = true
    var boolean2: Boolean = false

    var short: Short = 5
    var age: Int = 25
    var float: Float = 19.5f
    var double: Double = 29.5

    var char: Char = 'K'
    var name = "Kotlin :)"

    name = "Kotlin 2024"

    val githubId = "https://github.com/33Alireza/Kotlin"

    print(githubId)

    println()

    var a = 1
    var b = 2
    a = b.also { b = a }

}