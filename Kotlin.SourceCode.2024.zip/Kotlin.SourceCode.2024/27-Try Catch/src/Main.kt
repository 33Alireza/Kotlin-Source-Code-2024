fun main() {

    val a = 15
    val b = 5

   try {
        val c = a / b
        println(c)
    } catch (e: Exception) {
        println(e.message)
        println("Number b is not authentic")
    } finally {
        println("Finally")
    }

    println()

    val c : Int = try {
        a/b
    } catch (e:Exception){
        0
    }

    println(c)

}