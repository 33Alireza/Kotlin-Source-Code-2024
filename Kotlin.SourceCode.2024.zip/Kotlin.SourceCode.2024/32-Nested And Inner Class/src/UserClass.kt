class UserClass {
    val name = "Kotlin"

    fun showName() {
        println("Name is $name")
    }

    class City {
        val cityName = "Milano"

        fun showCity() {
            println("City is $cityName")
        }
    }

    class Age {
        val age = 28

        fun showAge() {
            println("Age is $age")
        }
    }
}