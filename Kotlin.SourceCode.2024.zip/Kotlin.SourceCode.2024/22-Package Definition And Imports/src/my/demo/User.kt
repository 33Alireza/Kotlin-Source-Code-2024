package my.demo

class User {

    var name = "Kotlin"
    var year = 2024

}