fun main() {

    val rectangle = Rectangle()
    rectangle.calculateArea()

}