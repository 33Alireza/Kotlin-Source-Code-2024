fun printMessageWithPrefix(message: String, prefix: String = "Info") {

    println("[$prefix] $message")

}

fun main() {

    printMessageWithPrefix("Hello", "Log")

    println()

    printMessageWithPrefix("Hello")

    println()

    printMessageWithPrefix(prefix = "Log", message = "Hello")

}