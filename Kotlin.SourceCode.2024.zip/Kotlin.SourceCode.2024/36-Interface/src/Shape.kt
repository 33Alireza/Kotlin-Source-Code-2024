interface Shape {

    var length: Int
    var width: Int

    fun calculateArea()

    fun test2() {
        //test
    }

}