interface Shape2 {

    var testShape2: String
    
}