data class User(val name: String, val id: Int)
