fun main() {

    val user = User("Alex", 1)
    println(user)

    println()

    val secondUser = User("Alex", 1)
    val thirdUser = User("Max", 2)

    println("${user.name} == ${secondUser.name}: ${user == secondUser}")
    println("${user.name} == ${thirdUser.name}: ${user == thirdUser}")

    println()

    println(user.copy("Max"))
    println(user.copy(id = 3))
}