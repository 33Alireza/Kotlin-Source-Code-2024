fun main() {

    val user = User()
    user.setValues("Kotlin", "JetBrains")
    user.getValues()

}

fun User.setValues(_lang: String, _company: String) {
    lang = _lang
    company = _company
}

fun User.getValues() {
    println("$lang $company")
}