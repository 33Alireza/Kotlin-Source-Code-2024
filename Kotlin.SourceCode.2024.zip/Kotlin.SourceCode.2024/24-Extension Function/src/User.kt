class User {

    var lang : String = ""
    var company : String = ""

}