fun main() {

    val user = User(3)

}