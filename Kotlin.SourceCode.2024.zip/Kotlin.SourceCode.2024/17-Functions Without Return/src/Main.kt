fun printMessage(message: String) {

    println(message)

}
fun main() {

    printMessage("Hello")

}