package profile.gender

class Male {
}