package profile

class Human {
    var name: String? = null
    var family: String? = null

    fun showMyAge(age: Int) {
        println("My age is : $age")
    }
}