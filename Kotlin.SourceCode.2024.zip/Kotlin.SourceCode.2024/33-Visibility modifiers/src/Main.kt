fun main() {

    val publicClass = VMPublicClass()
    publicClass.name = "JetBrains"

    val privateClass = VMPrivateClass()
    //privateClass.

    val protectedClass = VMProtectedClass()
    //protectedClass.

    val internalClass = VMInternalClass()
    internalClass.name = "JetBrains"

}