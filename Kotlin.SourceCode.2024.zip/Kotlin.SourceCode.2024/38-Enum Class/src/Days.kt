enum class Days {
    SATURDAY,
    SUNDAY,
    MUNDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
}